import {defineField, defineType} from 'sanity'

export const pageType = defineType({
  name: 'page',
  title: 'Page',
  type: 'document',

  fields: [
    defineField({
      name: 'title',
      title: 'Page Title',
      type: 'string',
      validation: (Rule) => Rule.required(),
    }),

    defineField({
      name: 'slug',
      title: 'Slug',
      type: 'slug',
      options: {
        source: 'title',
        maxLength: 96,
      },
      validation: (Rule) => Rule.required(),
    }),

    defineField({
      name: 'sections',
      title: 'Page Sections',
      type: 'array',
      of: [
        {
          type: 'hero',
        },
        {
          type: 'serviceList',
        },
        {
          type: 'servicesCta',
        },
        {
          type: 'stats',
        },
        {
          type: 'marquee',
        },
        {
          type: 'intro',
        },
        {
          type: 'videoBand',
        },
        {
          type: 'appendingEnrichment',
        },
        {
          type: 'alsoOffered',
        },
        {
          type: 'compare',
        },
        {
          type: 'why',
        },
        {
          type: 'testimonials',
        },
        {
          type: 'finalCta',
        },
        {
          type: 'pageHero',
        },
        {
          type: 'process',
        },
        {
          type: 'caseStudies',
        },
      ],
    }),
  ],
})
